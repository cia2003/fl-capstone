import type { Film, Recommendation } from "@/types";
import { RankedResultItem, RankedResultItemSkeleton } from "./RankedResultItem";
import { getFilm } from "@/lib/api/ghibliClient";

type RankedResultListProps = {
  recommendations: Recommendation[], 
  loading?: boolean
}
export function RankedResultList({ recommendations, loading = false }: RankedResultListProps) {
  // const filmById = new Map(films.map(film => [film.id, film]));
  // console.log("RankedList", recommendations)
  if (loading) {
    return (
      <ol className="mt-5 space-y-4">
        {Array.from({ length: 1 }).map((_, index) => (
          <RankedResultItemSkeleton key={index} />
        ))}
      </ol>
    )
  }

  return (
    <ol className="mt-5 space-y-4">
      {
      recommendations.map(async (recommendation, index) => {
        const film = await getFilm(recommendation.filmId)

        return film ? <RankedResultItem key={recommendation.filmId} recommendation={recommendation} film={film} rank={index + 1} /> : null;
    })}
    </ol>
  );
}
